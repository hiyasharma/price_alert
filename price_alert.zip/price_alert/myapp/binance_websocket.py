import json
import threading
import websocket

btc_price = {'price': 0}

def on_message(ws, message):
    global btc_price
    data = json.loads(message)
    price = float(data['p'])  # 'p' is the price field in Binance trade data
    btc_price['price'] = price
    if price <= 33000:
        send_email(price)

def on_error(ws, error):
    print(f"Error: {error}")

def on_close(ws):
    print("### closed ###")

def on_open(ws):
    print("WebSocket connection opened.")

def start_websocket():
    websocket.enableTrace(True)
    ws = websocket.WebSocketApp("wss://stream.binance.com:9443/ws/btcusdt@trade",
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close)
    ws.on_open = on_open
    ws.run_forever()

def send_email(price):
    import smtplib
    from email.mime.text import MIMEText
    from decouple import config

    smtp_server = 'smtp.gmail.com'
    smtp_port = 587
    sender_email = config('EMAIL_HOST_USER')
    sender_password = config('EMAIL_HOST_PASSWORD')
    receiver_email = 'theoriginalak1@gmail.com'

    subject = 'BTC Price Alert'
    body = f'The price of BTC has reached {price} USD.'

    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
            print('Email sent successfully')
    except Exception as e:
        print(f'Error sending email: {e}')

# Start the WebSocket client in a separate thread
websocket_thread = threading.Thread(target=start_websocket)
websocket_thread.daemon = True
websocket_thread.start()
